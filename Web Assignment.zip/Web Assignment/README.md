# Latrobe-Web-Assignment
A Website to guide the Annual General Meeting (AGM) attendees.
